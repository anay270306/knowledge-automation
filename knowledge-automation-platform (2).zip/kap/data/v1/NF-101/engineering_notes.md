# Engineering Notes — NF-101

## Summary

Implemented scheduled PDF export for dashboards. Work spanned the scheduling
API, a new render worker path, and the notification/email pipeline.

## Implementation Details

- Added `ScheduledExport` entity with fields: `dashboard_id`, `recurrence`,
  `recipients`, `next_run_at`, `created_by`.
- Recurrence is stored as a cron-like expression internally, but the API only
  exposes the three supported presets (daily, weekly, monthly) to keep the
  UI simple for V1.
- Reused the existing on-demand dashboard-to-PDF renderer
  (`DashboardRenderer.render_pdf`) rather than writing a new renderer. The
  only change needed was making it callable outside of an HTTP request
  context (it previously assumed a request-scoped user session).
- Export execution is handled by the existing scheduled-jobs worker, which
  now polls the `ScheduledExport` table every 60 seconds for due exports.
- Email delivery reuses the existing transactional email service; a new
  template `scheduled_export_ready.html` was added.

## Edge Cases Handled

- If a dashboard is deleted while a scheduled export still references it,
  the export is automatically disabled and the owner is notified.
- If PDF rendering fails (e.g. dashboard has no widgets), the export is
  retried once after 5 minutes before being marked as failed for that run;
  it does not block subsequent scheduled runs.
- Recipient list is capped at 20 addresses per export to avoid abuse.

## Testing

- Unit tests for recurrence calculation (daily/weekly/monthly next-run
  logic), including month-end edge cases (e.g. scheduling on the 31st).
- Integration test covering the full path: create export -> simulate
  worker tick -> assert PDF generated -> assert email sent.
- Manual QA on three dashboard types (chart-heavy, table-heavy, mixed) to
  confirm PDF layout does not clip content.

## Known Follow-ups (not in this release)

- No support yet for exporting to Slack or shared drives — tracked as a
  separate future story.
- No per-recipient customization (e.g. different filters per person).
