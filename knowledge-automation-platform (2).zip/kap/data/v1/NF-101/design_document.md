# Design Document — Scheduled Dashboard PDF Export

## Problem Statement

Analysts currently must manually open each dashboard and click "Export as
PDF" whenever they want to share a report. This is repetitive for
recurring reports (e.g. a weekly ops summary) and is easy to forget,
leading to stale reports being shared.

## Goals

- Let users schedule recurring PDF exports of a dashboard.
- Deliver the exported PDF via email automatically.
- Keep the initial scope small: no new rendering engine, no external
  storage integrations.

## Non-Goals (V1)

- Exporting to destinations other than email (Slack, S3, shared drives).
- Per-recipient personalization of the exported content.
- Sub-daily recurrence (e.g. hourly exports).

## Architecture Overview

```
[User] -> [Scheduling API] -> [ScheduledExport table]
                                     |
                         [Scheduled Jobs Worker] (polls every 60s)
                                     |
                     [DashboardRenderer.render_pdf]
                                     |
                          [Transactional Email Service]
                                     |
                               [Recipients]
```

The scheduling API is a thin CRUD layer on top of the `ScheduledExport`
entity. The existing scheduled-jobs worker was extended with a new job
type rather than introducing a separate scheduler, to avoid operating two
independent scheduling systems.

## Data Model

`ScheduledExport`:
- `id`
- `dashboard_id` (FK)
- `recurrence` (enum: DAILY, WEEKLY, MONTHLY)
- `recipients` (list of email addresses, max 20)
- `next_run_at` (timestamp)
- `created_by` (user id)
- `status` (ACTIVE, DISABLED)

## Failure Handling

Rendering failures are retried once after a fixed delay. Repeated failures
disable the specific run but leave the schedule active for the next cycle,
so a single bad dashboard state doesn't permanently break a recurring
export.

## Alternatives Considered

- **Dedicated export microservice**: rejected for V1 as unnecessary
  operational overhead given existing worker infrastructure could absorb
  the load.
- **Client-side scheduled export (browser must be open)**: rejected
  because it does not meet the "automatic, no manual action" requirement
  from the acceptance criteria.

## Rollout Plan

Feature-flagged rollout to internal workspaces first, then general
availability in release 2.9.0.
