# Engineering Notes — NF-102

## Root Cause

The invoice PDF renderer used a single hardcoded `"%.2f"` currency
formatter for all currencies. Zero-decimal currencies (JPY, KRW, VND) were
never special-cased, so amounts already stored in the correct minor-unit
convention were displayed with two fabricated decimal places.

## Fix

- Introduced `CurrencyFormatter` which looks up the correct decimal
  precision per ISO 4217 currency code instead of assuming two decimals
  everywhere.
- Updated `InvoicePdfRenderer` to call `CurrencyFormatter.format(amount,
  currency_code)` for every line item and the total.
- Backfilled a lookup table of zero-decimal currencies (JPY, KRW, VND,
  CLP) since these are the only ones the billing system currently
  supports issuing invoices in.

## Testing

- Added regression tests generating sample invoices in USD, EUR, GBP,
  JPY, KRW to confirm decimal precision matches currency rules.
- Verified against 12 real historical JPY invoices (anonymized) that the
  displayed total now matches the charged amount in the payment ledger.
- No changes required to the underlying amount storage — the bug was
  purely a display/formatting issue, not a calculation error, so no data
  backfill or customer refund is needed.

## Deployment Notes

- Fix is backward compatible; no schema changes.
- Rendered PDFs are not cached long-term, so the fix applies to all
  invoices generated after deploy without needing to regenerate historical
  PDFs. Customers who need a corrected copy of a past invoice can
  re-download it, which will regenerate with the fix applied.
