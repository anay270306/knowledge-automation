# Design Note — Currency Formatting Fix

This was a targeted bug fix rather than a new design, but a short design
note was written because the fix touches a shared formatting utility used
across invoices, receipts, and the billing dashboard.

## Problem

`InvoicePdfRenderer` formatted all currency amounts with a fixed two
decimal places, which is incorrect for zero-decimal currencies such as
JPY.

## Approach

Introduce a small `CurrencyFormatter` utility, driven by a static
lookup table of currency codes to decimal precision, and have all
currency-rendering call sites go through it instead of formatting
manually.

## Scope Decision

We considered formatting via a general-purpose i18n/locale library
instead of a static lookup table, but decided a static table was
sufficient because the billing system only issues invoices in a fixed,
small set of currencies that changes rarely and requires a compliance
review before any addition. This keeps the fix minimal and easy to
verify.

## Impact on Other Surfaces

The receipts view and billing dashboard summary already used a separate,
correct formatter, so this fix only needed to be applied to the invoice
PDF renderer. A follow-up cleanup ticket was filed to consolidate all
three call sites onto the same `CurrencyFormatter` utility so this class
of bug can't recur.
