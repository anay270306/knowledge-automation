# Design Document — Event-Driven Notification Consumer

## Problem Statement

`notification-service` polls the `outbound_events` table every 5 seconds
to find new events to dispatch. This adds up to 5 seconds of avoidable
latency per notification and puts a constant, low-value read load on the
database regardless of whether there are any pending events.

## Goals

- Remove polling latency from the notification pipeline.
- Reduce steady-state database load from the consumer.
- Preserve at-least-once delivery and existing dedupe guarantees.

## Non-Goals

- Changing the `NotificationDispatcher` dispatch logic itself.
- Migrating other services off the `outbound_events` table (out of scope;
  tracked separately per service as needed).

## Architecture Overview

```
Before:
[outbound_events table] <--poll every 5s-- [notification-service]

After:
[Event Bus] --push--> [EventBusSubscriber] --> [NotificationDispatcher]
       ^
       |
[Producers publish directly, in addition to writing outbound_events for audit]
```

## Design Decisions

- **Keep `outbound_events` as an audit/replay log**: several downstream
  consumers still read historical rows for debugging, and removing the
  table entirely would be a larger, riskier change than this ticket's
  scope.
- **Reuse the existing event bus** rather than introducing a new
  messaging system, since billing and audit-log services already run a
  supported subscriber pattern against it.
- **At-least-once delivery**: the event bus does not guarantee
  exactly-once delivery. `NotificationDispatcher` already dedupes by
  `event_id`, so this is safe without additional changes.

## Alternatives Considered

- **Reduce polling interval instead of switching to push**: rejected —
  would reduce latency somewhat but not eliminate the underlying
  database load problem, and pushes latency asymptotically toward zero
  only at the cost of even higher constant load.

## Rollout Plan

Shadow mode for 48 hours, then cutover behind a feature flag with
one-command rollback to polling if needed.
