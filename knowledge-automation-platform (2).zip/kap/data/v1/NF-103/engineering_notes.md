# Engineering Notes — NF-103

## Summary

Replaced the polling-based outbound-events consumer in notification-service
with a direct subscription to the event bus (the same bus already used by
the billing and audit-log services).

## Implementation Details

- Removed `PollingEventConsumer` (5-second interval `SELECT ... WHERE
  processed = false` loop against `outbound_events`).
- Added `EventBusSubscriber`, which subscribes to the `notifications.*`
  topic family and dispatches directly to the existing
  `NotificationDispatcher`, unchanged.
- `outbound_events` table is kept for now as an audit trail / replay
  source, but is no longer read on the hot path.
- Delivery semantics moved from at-most-once (a missed poll cycle could
  silently skip an event if a row was inserted and updated within one
  interval) to at-least-once with idempotent dispatch, since
  `NotificationDispatcher` already dedupes on `event_id`.

## Testing

- Load test replaying 10k events showed p95 delivery latency dropped
  from ~6.1s to ~0.4s.
- Verified idempotency by intentionally redelivering the same event
  twice and confirming only one notification was sent.
- Ran both consumers in shadow mode (polling disabled, event bus enabled,
  writes to a staging notification channel) for 48 hours before cutover
  to compare event counts — matched exactly.

## Rollback Plan

`PollingEventConsumer` was not deleted, only disabled via a feature flag,
so rollback is a single config change if issues are found post-deploy.

## Notes

Purely an internal infrastructure change. No API contracts, database
schemas visible to other services, or user-facing behavior changed.
