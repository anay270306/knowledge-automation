import { useState, FormEvent } from "react";

// Defaults to the backend's local dev address so the app works out of
// the box with `uvicorn backend.main:app --reload`. Override by setting
// VITE_API_BASE_URL (e.g. in a .env file) if the backend runs elsewhere.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000";

// Mirrors backend/config.py SUPPORTED_TRANSFORMATIONS.
const TRANSFORMATIONS = [
  { value: "sales_summary", label: "Sales Summary" },
  { value: "customer_release_notes", label: "Customer Release Notes" },
  { value: "support_guide", label: "Support Guide" },
  { value: "faq", label: "FAQ" },
  { value: "internal_summary", label: "Internal Summary" },
] as const;

interface GenerateResponse {
  success: true;
  issueKey: string;
  transformation: string;
  content: string;
}

interface ErrorResponse {
  success: false;
  error: string;
  detail: string;
}

export default function App() {
  const [issueKey, setIssueKey] = useState("");
  const [transformation, setTransformation] = useState<string>(
    TRANSFORMATIONS[0].value
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<GenerateResponse | null>(null);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const trimmedIssueKey = issueKey.trim();
    if (!trimmedIssueKey) {
      setError("Please enter an issue key.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch(`${API_BASE_URL}/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          issueKey: trimmedIssueKey,
          transformation,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        const errorData = data as ErrorResponse;
        throw new Error(errorData.detail ?? "Something went wrong.");
      }

      setResult(data as GenerateResponse);
    } catch (err) {
      if (err instanceof TypeError) {
        // fetch() throws a TypeError on network failure (e.g. backend not running).
        setError(
          `Could not reach the backend at ${API_BASE_URL}. Is it running?`
        );
      } else {
        setError(err instanceof Error ? err.message : "Something went wrong.");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex justify-center px-4 py-12">
      <div className="w-full max-w-xl">
        <header className="mb-8">
          <h1 className="text-2xl font-semibold text-slate-900">
            Knowledge Automation Platform
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            V1 demo — generate a stakeholder-specific representation from an
            existing issue.
          </p>
        </header>

        <form
          onSubmit={handleSubmit}
          className="bg-white border border-slate-200 rounded-lg p-6 space-y-5"
        >
          <div>
            <label
              htmlFor="issueKey"
              className="block text-sm font-medium text-slate-700 mb-1"
            >
              Issue Key
            </label>
            <input
              id="issueKey"
              type="text"
              value={issueKey}
              onChange={(e) => setIssueKey(e.target.value)}
              placeholder="NF-101"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm
                         focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          <div>
            <label
              htmlFor="transformation"
              className="block text-sm font-medium text-slate-700 mb-1"
            >
              Transformation
            </label>
            <select
              id="transformation"
              value={transformation}
              onChange={(e) => setTransformation(e.target.value)}
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm bg-white
                         focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              {TRANSFORMATIONS.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white
                       hover:bg-indigo-500 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading ? "Generating…" : "Generate"}
          </button>
        </form>

        {error && (
          <div className="mt-4 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        {result && (
          <div className="mt-6 bg-white border border-slate-200 rounded-lg p-6">
            <div className="flex items-baseline justify-between mb-3">
              <h2 className="text-sm font-medium text-slate-700">
                {result.issueKey} · {result.transformation}
              </h2>
            </div>
            <pre className="whitespace-pre-wrap font-mono text-sm text-slate-800 leading-relaxed">
              {result.content}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
