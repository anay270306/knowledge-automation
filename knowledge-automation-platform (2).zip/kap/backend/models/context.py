"""
Pydantic models representing the unified Context for a software
development issue.

These models are the shared "contract" between:

- connectors (which produce raw data)
- the context builder (which assembles this Context)
- the transformation service (which consumes this Context)

Keeping this contract explicit is what lets future connectors (Jira REST
API, GitHub, SharePoint, Confluence, Azure DevOps, ...) be swapped in
without touching the context builder or transformation service: as long
as a connector can produce data that fits this shape, everything
downstream keeps working unchanged.
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class JiraStory(BaseModel):
    """Structured representation of a jira_story.json artifact."""

    issue_key: str
    issue_type: str
    title: str
    description: str
    priority: str
    status: str
    reporter: Optional[str] = None
    assignee: Optional[str] = None
    story_points: Optional[int] = None
    epic_link: Optional[str] = None
    labels: List[str] = Field(default_factory=list)
    acceptance_criteria: List[str] = Field(default_factory=list)
    sprint: Optional[str] = None
    fix_version: Optional[str] = None


class IssueMetadata(BaseModel):
    """Structured representation of a metadata.json artifact."""

    issue_key: str
    team: Optional[str] = None
    component: Optional[str] = None
    release_version: Optional[str] = None
    target_release_date: Optional[str] = None
    customer_facing: bool = False
    risk_level: Optional[str] = None
    affected_modules: List[str] = Field(default_factory=list)
    requires_migration: bool = False
    tags: List[str] = Field(default_factory=list)


class IssueContext(BaseModel):
    """The unified Context for a single issue.

    This is the merged view of every artifact associated with an issue
    (Jira story, engineering notes, design document, and metadata),
    assembled by the Context Builder and consumed by the Transformation
    Service. It contains no derived or computed business fields on
    purpose — the Context Builder's job is only to merge, not to
    interpret.
    """

    issue_key: str
    story: JiraStory
    engineering_notes: str
    design_document: str
    metadata: IssueMetadata
