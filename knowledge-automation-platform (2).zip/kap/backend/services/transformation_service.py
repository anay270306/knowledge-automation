"""
Transformation Service.

Responsible ONLY for transforming an `IssueContext` into one of the
supported stakeholder-specific representations. All transformations are
deterministic — driven by templates and simple business rules over the
Context's fields (issue_type, customer_facing, priority, etc.) — with no
AI or external calls involved.

Adding a new transformation in a future version means adding one new
`_build_x` method and registering it in `_TRANSFORMATIONS`; nothing else
in the backend needs to change.
"""

from __future__ import annotations

import logging
from typing import Callable, Dict, List

from backend.config import (
    CUSTOMER_RELEASE_NOTES,
    FAQ,
    INTERNAL_SUMMARY,
    SALES_SUMMARY,
    SUPPORT_GUIDE,
    SUPPORTED_TRANSFORMATIONS,
)
from backend.models.context import IssueContext
from backend.utils.exceptions import UnsupportedTransformationError
from backend.utils.markdown_utils import extract_section, first_paragraph

logger = logging.getLogger(__name__)


class TransformationService:
    """Transforms a unified IssueContext into a requested representation."""

    def transform(self, context: IssueContext, transformation: str) -> str:
        builder = self._TRANSFORMATIONS.get(transformation)
        if builder is None:
            raise UnsupportedTransformationError(
                transformation, SUPPORTED_TRANSFORMATIONS
            )
        logger.info(
            "Transforming issue '%s' into '%s'.", context.issue_key, transformation
        )
        return builder(self, context)

    # ------------------------------------------------------------------
    # Sales Summary
    # ------------------------------------------------------------------

    def _build_sales_summary(self, context: IssueContext) -> str:
        story = context.story
        metadata = context.metadata

        if not metadata.customer_facing:
            return (
                f"{story.title}\n"
                f"{'=' * len(story.title)}\n\n"
                "This is an internal engineering change with no direct customer "
                "impact. It is not recommended as a customer-facing sales or "
                "renewal talking point.\n\n"
                f"Internal context: {first_paragraph(story.description)}"
            )

        value_points = story.acceptance_criteria or [story.description]
        release_line = self._format_release_line(metadata)

        lines: List[str] = [
            story.title,
            "=" * len(story.title),
            "",
            self._one_liner(story, metadata),
            "",
            "Why it matters to customers:",
            _bullet_list(value_points),
            "",
            release_line,
        ]
        return "\n".join(lines).strip() + "\n"

    def _one_liner(self, story, metadata) -> str:
        if story.issue_type.lower() == "bug":
            return (
                f"We resolved an issue where {self._lowered(story.description)}"
            )
        return story.description

    @staticmethod
    def _lowered(text: str) -> str:
        return text[0].lower() + text[1:] if text else text

    # ------------------------------------------------------------------
    # Customer Release Notes
    # ------------------------------------------------------------------

    def _build_customer_release_notes(self, context: IssueContext) -> str:
        story = context.story
        metadata = context.metadata

        if not metadata.customer_facing:
            return (
                f"{story.issue_key}: internal change, not included in "
                "customer-facing release notes."
            )

        category = self._release_note_category(story.issue_type)
        version_label = metadata.release_version or "an upcoming release"

        lines: List[str] = [
            f"{category} ({version_label})",
            "",
            f"**{story.title}**",
            "",
            story.description,
        ]

        if story.acceptance_criteria:
            lines += ["", "What's included:", _bullet_list(story.acceptance_criteria)]

        return "\n".join(lines).strip() + "\n"

    @staticmethod
    def _release_note_category(issue_type: str) -> str:
        normalized = issue_type.lower()
        if normalized == "bug":
            return "Fixed"
        if normalized in ("story", "feature"):
            return "New"
        return "Improved"

    # ------------------------------------------------------------------
    # Support Guide
    # ------------------------------------------------------------------

    def _build_support_guide(self, context: IssueContext) -> str:
        story = context.story
        metadata = context.metadata

        lines: List[str] = [
            f"Support Guide: {story.title}",
            "",
            f"Issue Key: {story.issue_key}",
            f"Type: {story.issue_type} | Priority: {story.priority}",
            f"Customer-facing: {'Yes' if metadata.customer_facing else 'No'}",
            "",
            "What changed:",
            story.description,
        ]

        if story.acceptance_criteria:
            lines += [
                "",
                "Expected behavior (use to confirm the fix/feature is working "
                "as intended):",
                _bullet_list(story.acceptance_criteria),
            ]

        edge_cases = extract_section(
            context.engineering_notes, ["edge case", "known issue", "known follow"]
        )
        if edge_cases:
            lines += ["", "Known edge cases / limitations:", edge_cases]

        if metadata.affected_modules:
            lines += [
                "",
                "Affected systems (useful for routing escalations):",
                _bullet_list(metadata.affected_modules),
            ]

        return "\n".join(lines).strip() + "\n"

    # ------------------------------------------------------------------
    # FAQ
    # ------------------------------------------------------------------

    def _build_faq(self, context: IssueContext) -> str:
        story = context.story
        metadata = context.metadata

        qa_pairs: List[tuple[str, str]] = []

        qa_pairs.append((f"What is '{story.title}'?", story.description))

        problem_statement = extract_section(
            context.design_document, ["problem"]
        )
        if problem_statement:
            qa_pairs.append(
                ("Why was this change made?", first_paragraph(problem_statement))
            )

        if story.issue_type.lower() == "bug":
            qa_pairs.append(
                (
                    "Was I affected by this issue?",
                    "You may have been affected if you used the affected "
                    f"functionality before this fix shipped in "
                    f"{metadata.release_version or 'the listed release'}. "
                    "Contact support if you're unsure.",
                )
            )
        else:
            availability = (
                "This is available to all customers."
                if metadata.customer_facing
                else "This is an internal change and has no visible effect "
                "for customers."
            )
            qa_pairs.append(("Who can use this?", availability))

        release_answer = self._format_release_line(metadata)
        qa_pairs.append(("When is/was this released?", release_answer))

        lines: List[str] = [f"Frequently Asked Questions: {story.title}", ""]
        for question, answer in qa_pairs:
            lines += [f"Q: {question}", f"A: {answer}", ""]

        return "\n".join(lines).strip() + "\n"

    # ------------------------------------------------------------------
    # Internal Summary
    # ------------------------------------------------------------------

    def _build_internal_summary(self, context: IssueContext) -> str:
        story = context.story
        metadata = context.metadata

        lines: List[str] = [
            f"Internal Summary: {story.issue_key} — {story.title}",
            "",
            f"Type: {story.issue_type} | Priority: {story.priority} | "
            f"Status: {story.status}",
            f"Team: {metadata.team or 'Unknown'} | Component: "
            f"{metadata.component or 'Unknown'}",
            f"Sprint: {story.sprint or 'Unknown'} | Fix Version: "
            f"{story.fix_version or 'Unknown'}",
            f"Reporter: {story.reporter or 'Unknown'} | Assignee: "
            f"{story.assignee or 'Unknown'}",
            f"Customer-facing: {'Yes' if metadata.customer_facing else 'No'} | "
            f"Risk: {metadata.risk_level or 'Unknown'} | Requires migration: "
            f"{'Yes' if metadata.requires_migration else 'No'}",
            "",
            "Description:",
            story.description,
        ]

        if story.acceptance_criteria:
            lines += ["", "Acceptance Criteria:", _bullet_list(story.acceptance_criteria)]

        if metadata.affected_modules:
            lines += ["", "Affected Modules:", _bullet_list(metadata.affected_modules)]

        implementation_summary = extract_section(
            context.engineering_notes, ["implementation", "summary"]
        )
        if implementation_summary:
            lines += ["", "Implementation Notes:", implementation_summary]

        testing_notes = extract_section(context.engineering_notes, ["testing"])
        if testing_notes:
            lines += ["", "Testing:", testing_notes]

        follow_ups = extract_section(
            context.engineering_notes, ["follow-up", "follow up"]
        )
        if follow_ups:
            lines += ["", "Known Follow-ups:", follow_ups]

        design_decisions = extract_section(
            context.design_document, ["design decision", "approach", "alternative"]
        )
        if design_decisions:
            lines += ["", "Design Notes:", design_decisions]

        if story.labels or metadata.tags:
            all_tags = sorted(set(story.labels) | set(metadata.tags))
            lines += ["", f"Tags: {', '.join(all_tags)}"]

        return "\n".join(lines).strip() + "\n"

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _format_release_line(metadata) -> str:
        version = metadata.release_version or "an upcoming release"
        date = metadata.target_release_date
        if date:
            return f"Available in {version}, targeted for {date}."
        return f"Available in {version}."

    # Registry mapping transformation keys to builder methods. Defined
    # at the bottom of the class body so it can reference the methods
    # above by name.
    _TRANSFORMATIONS: Dict[str, Callable[["TransformationService", IssueContext], str]]


TransformationService._TRANSFORMATIONS = {
    SALES_SUMMARY: TransformationService._build_sales_summary,
    CUSTOMER_RELEASE_NOTES: TransformationService._build_customer_release_notes,
    SUPPORT_GUIDE: TransformationService._build_support_guide,
    FAQ: TransformationService._build_faq,
    INTERNAL_SUMMARY: TransformationService._build_internal_summary,
}


def _bullet_list(items: List[str]) -> str:
    return "\n".join(f"- {item}" for item in items)
