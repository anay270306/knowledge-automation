"""
Context Builder.

Responsible ONLY for combining the raw artifacts of an issue (jira_story,
engineering_notes, design_document, metadata) into one unified
`IssueContext` model. It contains no business logic — it does not decide
what any of the data *means*, it only validates shape and assembles it.
Interpreting the Context into stakeholder-specific output is the
Transformation Service's job (see transformation_service.py).
"""

from __future__ import annotations

import logging

from pydantic import ValidationError

from backend.connectors.base_connector import BaseConnector, RawArtifacts
from backend.models.context import IssueContext, IssueMetadata, JiraStory
from backend.utils.exceptions import InvalidArtifactDataError

logger = logging.getLogger(__name__)


class ContextBuilder:
    """Builds a unified IssueContext from a connector's raw artifacts."""

    def __init__(self, connector: BaseConnector) -> None:
        self._connector = connector

    def build(self, issue_key: str) -> IssueContext:
        raw: RawArtifacts = self._connector.get_raw_artifacts(issue_key)
        return self._merge(raw)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _merge(self, raw: RawArtifacts) -> IssueContext:
        story = self._parse_model(
            JiraStory, raw.jira_story, raw.issue_key, "jira_story.json"
        )
        metadata = self._parse_model(
            IssueMetadata, raw.metadata, raw.issue_key, "metadata.json"
        )

        context = IssueContext(
            issue_key=raw.issue_key,
            story=story,
            engineering_notes=raw.engineering_notes,
            design_document=raw.design_document,
            metadata=metadata,
        )

        logger.info("Built context for issue '%s'.", raw.issue_key)
        return context

    @staticmethod
    def _parse_model(model_cls, data: dict, issue_key: str, filename: str):
        try:
            return model_cls.model_validate(data)
        except ValidationError as exc:
            raise InvalidArtifactDataError(
                issue_key, filename, _summarize_validation_error(exc)
            ) from exc


def _summarize_validation_error(exc: ValidationError) -> str:
    """Produce a short, human-readable summary of a Pydantic validation
    error instead of surfacing its full (verbose) representation."""
    problems = []
    for error in exc.errors():
        location = ".".join(str(part) for part in error["loc"])
        problems.append(f"{location}: {error['msg']}")
    return "; ".join(problems)
