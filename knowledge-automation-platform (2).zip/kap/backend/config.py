"""
Central configuration for the Knowledge Automation Platform backend.

Keeping all paths, constants, and environment-driven settings in one
place makes it easy to swap the local dataset for a real data source in
a future version without hunting through the codebase for hardcoded
values.
"""

from __future__ import annotations

import logging
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

# backend/config.py -> backend/ -> project root
PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent

# V1 uses a local synthetic dataset laid out as data/v1/<ISSUE_KEY>/...
DATA_ROOT: Path = PROJECT_ROOT / "data" / "v1"

# ---------------------------------------------------------------------------
# Dataset file names
# ---------------------------------------------------------------------------

JIRA_STORY_FILENAME = "jira_story.json"
ENGINEERING_NOTES_FILENAME = "engineering_notes.md"
DESIGN_DOCUMENT_FILENAME = "design_document.md"
METADATA_FILENAME = "metadata.json"

REQUIRED_ARTIFACT_FILENAMES = (
    JIRA_STORY_FILENAME,
    ENGINEERING_NOTES_FILENAME,
    DESIGN_DOCUMENT_FILENAME,
    METADATA_FILENAME,
)

# ---------------------------------------------------------------------------
# Supported transformations
# ---------------------------------------------------------------------------

SALES_SUMMARY = "sales_summary"
CUSTOMER_RELEASE_NOTES = "customer_release_notes"
SUPPORT_GUIDE = "support_guide"
FAQ = "faq"
INTERNAL_SUMMARY = "internal_summary"

SUPPORTED_TRANSFORMATIONS = (
    SALES_SUMMARY,
    CUSTOMER_RELEASE_NOTES,
    SUPPORT_GUIDE,
    FAQ,
    INTERNAL_SUMMARY,
)

# ---------------------------------------------------------------------------
# App metadata
# ---------------------------------------------------------------------------

APP_TITLE = "Knowledge Automation Platform"
APP_VERSION = "1.0.0"
APP_DESCRIPTION = (
    "Transforms existing software development knowledge into "
    "stakeholder-specific representations."
)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

LOG_LEVEL = logging.INFO
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
