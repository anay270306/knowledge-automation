"""
API routes for the Knowledge Automation Platform.

Routes are intentionally thin: they parse input, delegate to the
services layer, and shape the response. All error translation from
domain exceptions to HTTP status codes happens via the exception
handlers registered in main.py, so routes don't need try/except blocks
of their own.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Path

from backend.api.schemas import GenerateRequest, GenerateResponse
from backend.connectors.jira_connector import JiraConnector
from backend.models.context import IssueContext
from backend.services.context_builder import ContextBuilder
from backend.services.transformation_service import TransformationService

router = APIRouter()

# ---------------------------------------------------------------------------
# Dependency wiring
#
# V1 wires a single connector (JiraConnector, reading the local synthetic
# dataset). Swapping in a different data source in a future version means
# changing only this wiring, not the routes or services themselves — both
# depend only on the BaseConnector interface via ContextBuilder.
# ---------------------------------------------------------------------------

_connector = JiraConnector()
_context_builder = ContextBuilder(_connector)
_transformation_service = TransformationService()


def get_context_builder() -> ContextBuilder:
    return _context_builder


def get_transformation_service() -> TransformationService:
    return _transformation_service


@router.get(
    "/story/{issueKey}",
    response_model=IssueContext,
    tags=["Story"],
    summary="Load an issue and return its complete, unified Context",
)
def get_story(
    issueKey: str = Path(..., description="Issue key, e.g. 'NF-101'"),
    context_builder: ContextBuilder = Depends(get_context_builder),
) -> IssueContext:
    return context_builder.build(issueKey)


@router.post(
    "/generate",
    response_model=GenerateResponse,
    tags=["Generate"],
    summary="Generate a stakeholder-specific representation for an issue",
)
def generate(
    request: GenerateRequest,
    context_builder: ContextBuilder = Depends(get_context_builder),
    transformation_service: TransformationService = Depends(
        get_transformation_service
    ),
) -> GenerateResponse:
    context = context_builder.build(request.issue_key)
    content = transformation_service.transform(context, request.transformation)
    return GenerateResponse(
        success=True,
        issueKey=request.issue_key,
        transformation=request.transformation,
        content=content,
    )
