"""
Request/response schemas for the public API.

Kept separate from the internal domain models in models/context.py:
these describe the HTTP contract (including camelCase field names to
match the API spec), while models/context.py describes the internal
domain shape. That separation means the internal models are free to
evolve without breaking the public HTTP contract, and vice versa.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from backend.config import SUPPORTED_TRANSFORMATIONS


class GenerateRequest(BaseModel):
    """Request body for POST /generate."""

    model_config = ConfigDict(populate_by_name=True)

    issue_key: str = Field(
        alias="issueKey", min_length=1, description="e.g. 'NF-101'"
    )
    transformation: str = Field(
        min_length=1,
        description=f"One of: {', '.join(SUPPORTED_TRANSFORMATIONS)}",
    )


class GenerateResponse(BaseModel):
    """Response body for POST /generate."""

    model_config = ConfigDict(populate_by_name=True)

    success: bool = True
    issue_key: str = Field(alias="issueKey")
    transformation: str
    content: str


class ErrorResponse(BaseModel):
    """Standard error envelope returned for all handled failure cases."""

    success: bool = False
    error: str
    detail: str
