"""
JiraConnector — V1 implementation of BaseConnector.

Responsible ONLY for reading raw artifact files for a given issue key
from the local synthetic dataset (data/v1/<ISSUE_KEY>/). It does not
merge artifacts and does not know anything about how they will be used
downstream.

In a future version, this class could be replaced by a connector that
calls the real Jira REST API instead of reading local files — the rest
of the backend (Context Builder, Transformation Service, API layer)
would not need to change, since both connectors produce the same
`RawArtifacts` shape.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict

from backend.config import (
    DATA_ROOT,
    DESIGN_DOCUMENT_FILENAME,
    ENGINEERING_NOTES_FILENAME,
    JIRA_STORY_FILENAME,
    METADATA_FILENAME,
)
from backend.connectors.base_connector import BaseConnector, RawArtifacts
from backend.utils.exceptions import (
    InvalidArtifactDataError,
    InvalidIssueKeyError,
    IssueNotFoundError,
    MissingArtifactError,
)

logger = logging.getLogger(__name__)

# Issue keys are expected to look like 'NF-101': letters, digits,
# hyphens, and underscores only. This also doubles as a guard against
# path traversal (e.g. '../../etc/passwd') since '/' and '.' are
# rejected outright.
_VALID_ISSUE_KEY_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


class JiraConnector(BaseConnector):
    """Reads issue artifacts from the local dataset directory."""

    def __init__(self, data_root: Path = DATA_ROOT) -> None:
        self._data_root = data_root

    def get_raw_artifacts(self, issue_key: str) -> RawArtifacts:
        issue_dir = self._resolve_issue_dir(issue_key)

        jira_story = self._read_json(issue_dir, JIRA_STORY_FILENAME, issue_key)
        metadata = self._read_json(issue_dir, METADATA_FILENAME, issue_key)
        engineering_notes = self._read_text(
            issue_dir, ENGINEERING_NOTES_FILENAME, issue_key
        )
        design_document = self._read_text(
            issue_dir, DESIGN_DOCUMENT_FILENAME, issue_key
        )

        logger.info("Loaded raw artifacts for issue '%s'.", issue_key)

        return RawArtifacts(
            issue_key=issue_key,
            jira_story=jira_story,
            engineering_notes=engineering_notes,
            design_document=design_document,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_issue_dir(self, issue_key: str) -> Path:
        if not issue_key or not _VALID_ISSUE_KEY_PATTERN.match(issue_key):
            logger.warning("Rejected malformed issue key: '%s'.", issue_key)
            raise InvalidIssueKeyError(issue_key)

        issue_dir = self._data_root / issue_key
        if not issue_dir.is_dir():
            logger.warning("Issue folder not found for '%s'.", issue_key)
            raise IssueNotFoundError(issue_key)
        return issue_dir

    def _read_text(self, issue_dir: Path, filename: str, issue_key: str) -> str:
        file_path = issue_dir / filename
        if not file_path.is_file():
            raise MissingArtifactError(issue_key, filename)
        try:
            return file_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise InvalidArtifactDataError(issue_key, filename, str(exc)) from exc

    def _read_json(
        self, issue_dir: Path, filename: str, issue_key: str
    ) -> Dict[str, Any]:
        file_path = issue_dir / filename
        if not file_path.is_file():
            raise MissingArtifactError(issue_key, filename)
        try:
            raw_text = file_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise InvalidArtifactDataError(issue_key, filename, str(exc)) from exc

        try:
            data = json.loads(raw_text)
        except json.JSONDecodeError as exc:
            raise InvalidArtifactDataError(
                issue_key, filename, f"invalid JSON ({exc.msg})"
            ) from exc

        if not isinstance(data, dict):
            raise InvalidArtifactDataError(
                issue_key, filename, "expected a JSON object at the top level"
            )

        return data
