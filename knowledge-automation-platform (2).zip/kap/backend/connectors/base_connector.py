"""
Connector interface.

A connector's only job is to fetch the raw artifacts for a given issue
key from *some* data source and return them in a uniform shape
(`RawArtifacts`). It does no merging, no interpretation, and no
transformation.

V1 ships a single implementation, `JiraConnector` (see
jira_connector.py), which reads from the local synthetic dataset.

Future versions can add new connectors (e.g. a real Jira REST API
connector, a GitHub connector, a SharePoint/Confluence connector) by
implementing this same interface. Nothing in the Context Builder or
Transformation Service needs to change when that happens — they only
depend on `RawArtifacts`, not on how it was produced.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict


@dataclass(frozen=True)
class RawArtifacts:
    """Uniform, connector-agnostic representation of an issue's raw
    artifacts, before any merging or interpretation happens."""

    issue_key: str
    jira_story: Dict[str, Any]
    engineering_notes: str
    design_document: str
    metadata: Dict[str, Any]


class BaseConnector(ABC):
    """Abstract interface every data source connector must implement."""

    @abstractmethod
    def get_raw_artifacts(self, issue_key: str) -> RawArtifacts:
        """Fetch all raw artifacts for a given issue key.

        Implementations are responsible for raising the appropriate
        exception from backend.utils.exceptions when data is missing or
        malformed (IssueNotFoundError, MissingArtifactError,
        InvalidArtifactDataError). Callers should not need to know
        anything about the underlying data source.
        """
        raise NotImplementedError
