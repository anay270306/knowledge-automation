"""
Application entrypoint for the Knowledge Automation Platform backend.

Run locally with:

    uvicorn backend.main:app --reload

from the project root (the directory that contains both `backend/` and
`data/`).
"""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.api.routes import router
from backend.api.schemas import ErrorResponse
from backend.config import APP_DESCRIPTION, APP_TITLE, APP_VERSION
from backend.utils.exceptions import (
    InvalidArtifactDataError,
    InvalidIssueKeyError,
    IssueNotFoundError,
    MissingArtifactError,
    UnsupportedTransformationError,
)
from backend.utils.logging_config import configure_logging

configure_logging()
logger = logging.getLogger(__name__)

app = FastAPI(
    title=APP_TITLE,
    description=APP_DESCRIPTION,
    version=APP_VERSION,
)

# ---------------------------------------------------------------------------
# CORS
#
# The frontend (frontend/) runs as a separate Vite dev server process on a
# different origin/port than the backend, so the browser needs an explicit
# CORS allowance to call this API. Restricted to local dev origins only —
# this is a demo-only allowance, not a production CORS policy.
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1):\d+",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


def _error_response(status_code: int, error: str, detail: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(error=error, detail=detail).model_dump(),
    )


# ---------------------------------------------------------------------------
# Exception handlers
#
# Each domain exception (backend/utils/exceptions.py) maps to exactly one
# HTTP status code here. Routes never need to know about HTTP concerns —
# they just raise the right domain exception and this layer translates it.
# ---------------------------------------------------------------------------


@app.exception_handler(InvalidIssueKeyError)
async def handle_invalid_issue_key(
    request: Request, exc: InvalidIssueKeyError
) -> JSONResponse:
    logger.info("Invalid issue key: %s", exc)
    return _error_response(400, "invalid_issue_key", str(exc))


@app.exception_handler(IssueNotFoundError)
async def handle_issue_not_found(
    request: Request, exc: IssueNotFoundError
) -> JSONResponse:
    logger.info("Issue not found: %s", exc)
    return _error_response(404, "issue_not_found", str(exc))


@app.exception_handler(MissingArtifactError)
async def handle_missing_artifact(
    request: Request, exc: MissingArtifactError
) -> JSONResponse:
    # The issue folder exists but the dataset is incomplete for it. From
    # the caller's perspective this is a server-side data problem, not a
    # malformed request, so it is treated as a 500 rather than a 404.
    logger.error("Missing artifact: %s", exc)
    return _error_response(500, "missing_artifact", str(exc))


@app.exception_handler(InvalidArtifactDataError)
async def handle_invalid_artifact_data(
    request: Request, exc: InvalidArtifactDataError
) -> JSONResponse:
    logger.error("Invalid artifact data: %s", exc)
    return _error_response(500, "invalid_artifact_data", str(exc))


@app.exception_handler(UnsupportedTransformationError)
async def handle_unsupported_transformation(
    request: Request, exc: UnsupportedTransformationError
) -> JSONResponse:
    logger.info("Unsupported transformation requested: %s", exc)
    return _error_response(400, "unsupported_transformation", str(exc))


@app.exception_handler(RequestValidationError)
async def handle_request_validation_error(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    logger.info("Request validation failed: %s", exc)
    return _error_response(
        422, "invalid_request", "The request body failed validation."
    )


@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unexpected error while handling request.")
    return _error_response(
        500, "internal_server_error", "An unexpected error occurred."
    )


@app.get("/health", tags=["Health"], summary="Basic liveness check")
def health() -> dict:
    return {"status": "ok", "service": APP_TITLE, "version": APP_VERSION}
