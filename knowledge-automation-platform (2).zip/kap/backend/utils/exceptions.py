"""
Domain-specific exceptions for the Knowledge Automation Platform.

Each exception maps to a specific, predictable failure mode. The API
layer (see api/routes.py) catches these and translates them into
appropriate HTTP status codes, so the rest of the backend can simply
raise a meaningful exception instead of dealing with HTTP concerns
directly.
"""

from __future__ import annotations


class KnowledgeAutomationError(Exception):
    """Base class for all platform-specific errors."""


class InvalidIssueKeyError(KnowledgeAutomationError):
    """Raised when the supplied issue key is malformed (empty, or
    contains characters that are never valid in an issue key). This is
    distinct from IssueNotFoundError: the key is syntactically invalid,
    independent of whether any dataset entry could ever match it."""

    def __init__(self, issue_key: str) -> None:
        self.issue_key = issue_key
        super().__init__(f"Issue key '{issue_key}' is not a valid issue key.")


class IssueNotFoundError(KnowledgeAutomationError):
    """Raised when the requested issue key has no corresponding folder
    in the dataset."""

    def __init__(self, issue_key: str) -> None:
        self.issue_key = issue_key
        super().__init__(f"Issue '{issue_key}' was not found.")


class MissingArtifactError(KnowledgeAutomationError):
    """Raised when an issue folder exists but one or more required
    artifact files are missing."""

    def __init__(self, issue_key: str, filename: str) -> None:
        self.issue_key = issue_key
        self.filename = filename
        super().__init__(
            f"Issue '{issue_key}' is missing required artifact '{filename}'."
        )


class InvalidArtifactDataError(KnowledgeAutomationError):
    """Raised when an artifact file exists but cannot be parsed or does
    not match the expected structure (e.g. malformed JSON)."""

    def __init__(self, issue_key: str, filename: str, reason: str) -> None:
        self.issue_key = issue_key
        self.filename = filename
        self.reason = reason
        super().__init__(
            f"Issue '{issue_key}' has invalid data in '{filename}': {reason}"
        )


class UnsupportedTransformationError(KnowledgeAutomationError):
    """Raised when the requested transformation type is not supported."""

    def __init__(self, transformation: str, supported: tuple[str, ...]) -> None:
        self.transformation = transformation
        self.supported = supported
        super().__init__(
            f"Transformation '{transformation}' is not supported. "
            f"Supported transformations: {', '.join(supported)}."
        )
