"""Centralized logging configuration."""

from __future__ import annotations

import logging

from backend.config import LOG_FORMAT, LOG_LEVEL


def configure_logging() -> None:
    """Configure root logging once, at application startup.

    Idempotent: calling this more than once will not duplicate handlers.
    """
    root_logger = logging.getLogger()
    if root_logger.handlers:
        return

    logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
