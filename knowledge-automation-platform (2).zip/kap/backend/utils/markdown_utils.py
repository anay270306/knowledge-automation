"""
Small, dependency-free helpers for pulling specific sections out of the
markdown artifacts (engineering_notes.md, design_document.md).

This is intentionally simple: it splits on markdown headings (`#`..`######`)
and returns the body of the first section whose heading contains one of
the given keywords. It is used by the Transformation Service so multiple
templates can reuse the same extraction logic instead of each
re-implementing ad-hoc string parsing.
"""

from __future__ import annotations

import re
from typing import Iterable, List, Optional, Tuple

_HEADING_PATTERN = re.compile(r"^(#{1,6})\s+(.*)$")


def _split_into_sections(markdown_text: str) -> List[Tuple[str, str]]:
    """Split markdown text into (heading, body) pairs.

    Content before the first heading is returned under an empty-string
    heading so it is never silently dropped.
    """
    sections: List[Tuple[str, str]] = []
    current_heading = ""
    current_lines: List[str] = []

    for line in markdown_text.splitlines():
        match = _HEADING_PATTERN.match(line)
        if match:
            sections.append((current_heading, "\n".join(current_lines).strip()))
            current_heading = match.group(2).strip()
            current_lines = []
        else:
            current_lines.append(line)

    sections.append((current_heading, "\n".join(current_lines).strip()))
    return sections


def extract_section(markdown_text: str, keywords: Iterable[str]) -> Optional[str]:
    """Return the body of the first section whose heading contains any
    of the given keywords (case-insensitive substring match).

    Returns None if no matching section is found, so callers can decide
    how to gracefully handle absence instead of relying on exceptions
    for normal control flow.
    """
    lowered_keywords = [kw.lower() for kw in keywords]
    for heading, body in _split_into_sections(markdown_text):
        heading_lower = heading.lower()
        if any(kw in heading_lower for kw in lowered_keywords) and body:
            return body
    return None


def first_paragraph(text: str) -> str:
    """Return the first non-empty paragraph of a block of text."""
    for paragraph in text.strip().split("\n\n"):
        cleaned = paragraph.strip()
        if cleaned:
            return cleaned
    return ""
