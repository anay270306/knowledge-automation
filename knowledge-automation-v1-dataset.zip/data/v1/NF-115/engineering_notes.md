# Overview
This feature introduces the Customer Portal module's first capability, allowing customers to submit and track support tickets directly through a self-service interface.

# Backend Changes
Added a Customer Portal Service handling ticket creation, status tracking, and follow-up comments, scoped to a distinct customer account type separate from internal NovaFlow Workspace user accounts. Ticket confirmation emails are dispatched through the category-based Notification Service introduced in NF-109.

# Frontend Changes
Added a ticket submission form with subject, description, and category fields, a ticket list view showing status, and a ticket detail view supporting follow-up comments.

# Database Changes
Added tickets and ticket_comments tables, scoped to customer accounts, along with a customer_accounts table distinct from the internal user table.

# API Changes
Added endpoints for submitting a ticket, listing a customer's own tickets, retrieving ticket detail, and adding a follow-up comment.

# Validation
Ticket access is scoped strictly to the submitting customer account; a customer cannot view or comment on another customer's ticket.

# Performance
Ticket list queries are indexed by customer account to keep retrieval fast regardless of overall ticket volume across the platform.

# Testing
Covered by unit tests for ticket scoping and status transitions, integration tests for the full submission-to-confirmation-email flow using the NF-109 Notification Service, and manual QA of the follow-up comment flow.

# Deployment Notes
Requires new tickets, ticket_comments, and customer_accounts table migrations. No feature flag required since this is a net-new, isolated capability.

# Known Limitations
No support yet for file attachments on tickets. No internal support-agent-facing view for managing tickets; that is expected to be a separate future story.

# Future Improvements
Add file attachment support for tickets once File Management is available, and build an internal support-agent view for ticket management and response.
