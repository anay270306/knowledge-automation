# Problem Statement
Customers currently have no self-service way to submit support requests or track their status, relying entirely on email with no visibility into progress.

# Current Behaviour
No Customer Portal module exists; support requests, if any, happen entirely outside the platform.

# Proposed Solution
Introduce a self-service ticket submission and tracking capability, scoped to a distinct customer account type, with confirmation emails routed through the existing Notification Service.

# Architecture Considerations
Customer accounts were deliberately modeled as a separate account type from internal NovaFlow Workspace users, reflecting a narrower trust boundary and preventing any accidental exposure of internal module data to portal users.

# Assumptions
It is assumed that customers do not need visibility into other customers' tickets or any internal support team data at this stage.

# Risks
Introducing a second account type increases the surface area for access-control mistakes. This is mitigated by strict scoping of all portal queries to the authenticated customer account.

# Future Scope
File attachment support for tickets, and an internal support-agent-facing view for ticket management, which is expected to be addressed as a separate future story.
