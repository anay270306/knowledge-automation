# Overview
This feature introduces the Billing module's first capability: read-only visibility into subscription plan details and invoice history for organization administrators.

# Backend Changes
Added a Billing Service exposing current subscription plan details (seat count, renewal date) and a paginated invoice history endpoint, with status tracked per invoice (paid, pending, failed).

# Frontend Changes
Added a Billing section within the Admin Console showing a current plan summary and an invoice history table, with a download action per invoice.

# Database Changes
Added subscription_plans and invoices tables, with invoices linked to the owning organization and a status field.

# API Changes
Added endpoints for retrieving current plan details, listing invoice history, and downloading a specific invoice as a PDF.

# Validation
Access to all billing endpoints is gated through the permission group model introduced in NF-110, rather than a separate hardcoded check.

# Performance
Invoice history is paginated to keep response times consistent regardless of an organization's billing history length.

# Testing
Covered by unit tests for status filtering and PDF generation, integration tests for the full plan-and-invoice retrieval flow, and manual QA of the permission gating using NF-110 groups.

# Deployment Notes
Requires subscription_plans and invoices table migrations. No feature flag required since this is read-only, low-risk functionality.

# Known Limitations
No plan upgrade or downgrade capability. No payment method management. Invoice data is currently populated from a single billing data source with no reconciliation tooling.

# Future Improvements
Add self-service plan upgrade/downgrade, payment method management, and reconciliation tooling for billing discrepancies.
