# Problem Statement
Users who lose both their authenticator device and their recovery codes have no way to regain access to their account, since no self-service recovery path exists for this scenario following the introduction of MFA in NF-103.

# Current Behaviour
MFA, once enabled, can only be disabled through self-service verification using a TOTP code or recovery code, as established in NF-103. If both are lost, the user is permanently locked out with no available recourse.

# Proposed Solution
Introduce an administrator-assisted reset capability that clears a user's MFA enrollment entirely, requiring the user to re-enroll from scratch. The action is gated behind administrator re-authentication and produces an immutable audit record.

# Architecture Considerations
The reset was deliberately scoped to fully clear MFA state rather than attempting to restore or bypass it, avoiding any weakening of the security model established in NF-103. Reusing the existing notification pattern from NF-102 keeps the implementation consistent with prior authentication-related communications.

# Assumptions
It is assumed that organizations have a trusted administrator role capable of verifying user identity out-of-band before performing this reset, since the platform itself has no additional identity verification mechanism for this action.

# Risks
An administrator account with excessive trust or compromised credentials could misuse this capability to strip MFA protection from any user. The audit trail requirement partially mitigates this by ensuring accountability, though it does not prevent misuse.

# Future Scope
Future iterations may explore stronger identity verification requirements before an administrator can perform this action, as well as bulk reset tooling for larger organizations.
