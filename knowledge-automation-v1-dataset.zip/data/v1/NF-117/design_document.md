# Problem Statement
Sales representatives using the contact creation form from NF-108 over unstable network connections were experiencing duplicate contact records, caused by client-side retries the backend had no way to recognize as repeats of the same request.

# Current Behaviour
The contact creation endpoint from NF-108 treats every incoming request as a new creation attempt, with no mechanism to detect that two requests originated from the same user action.

# Proposed Solution
Introduce a client-generated idempotency key attached to each contact creation attempt, allowing the backend to recognize and safely ignore a retried request within a bounded time window.

# Architecture Considerations
The fix was scoped narrowly to the retry-duplication problem and deliberately does not touch or interact with the separate, intentional duplicate-email advisory warning introduced in NF-108, keeping the two concerns cleanly separated.

# Assumptions
It is assumed that client-side retries occur within a short time window after the original attempt, making a bounded idempotency window sufficient to catch the vast majority of real-world cases.

# Risks
A retry occurring after the idempotency window has expired would not be caught by this fix, though this scenario is considered rare based on observed retry behavior.

# Future Scope
Extending the idempotency key pattern to other module creation endpoints if similar duplication issues are reported elsewhere.
