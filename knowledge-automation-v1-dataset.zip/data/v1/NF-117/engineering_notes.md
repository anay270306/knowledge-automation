# Overview
This fixes a bug where an unstable network connection could cause a contact creation form submission to be retried client-side, resulting in duplicate contact records being created from what the user experienced as a single submission.

# Backend Changes
Added support for an idempotency key on the contact creation endpoint from NF-108. When a request is received with a key matching a recently processed request, the backend returns the original result rather than creating a new record.

# Frontend Changes
Updated the contact creation form to generate a client-side idempotency key once per submission attempt, reused automatically across any client-triggered retry of that same attempt.

# Database Changes
Added an idempotency_key column with a short-lived uniqueness constraint on the contacts table, used only to detect retried requests within a bounded time window.

# API Changes
The existing contact creation endpoint from NF-108 now accepts an optional idempotency key parameter; behavior is unchanged for requests that don't provide one.

# Validation
Requests with a duplicate idempotency key within the bounded window return the original creation result instead of creating a new record. The existing duplicate-email advisory warning from NF-108 is unaffected and continues to fire independently.

# Performance
Idempotency key lookups are indexed and scoped to a short retention window, avoiding any meaningful overhead on the creation path.

# Testing
Covered by unit tests for idempotency key matching and the bounded retention window, integration tests simulating a client retry on timeout to confirm only one contact record results, and regression tests confirming the NF-108 duplicate-email warning still fires correctly for genuinely distinct submissions.

# Deployment Notes
Requires the idempotency_key column migration on the contacts table. No feature flag required given the narrow, additive nature of the fix.

# Known Limitations
The idempotency window is time-bounded and does not protect against a retry occurring after the window has expired, though this covers the vast majority of observed real-world retry timing.

# Future Improvements
Consider extending the same idempotency key pattern to other creation endpoints across modules if similar retry-related duplication issues are reported.
