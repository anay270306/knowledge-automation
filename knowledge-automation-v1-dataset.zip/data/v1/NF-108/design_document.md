# Problem Statement
No central system exists for sales teams to track and manage the people and organizations they interact with, making it difficult to maintain consistent, shared contact information.

# Current Behaviour
No CRM capability exists in the platform at all; contact information, if tracked, would live entirely outside NovaFlow Workspace.

# Proposed Solution
Introduce a core contact record with full CRUD operations, search and filter capability, advisory duplicate detection, and soft-delete with a recovery window.

# Architecture Considerations
Soft-delete was chosen over hard delete to protect against accidental data loss, a common requirement in CRM-style tools. Duplicate detection is intentionally advisory rather than enforced, avoiding blocking legitimate scenarios such as shared team inboxes.

# Assumptions
It is assumed that a flat contact model is sufficient for v1, without a separate first-class company or account entity distinct from individual contacts.

# Risks
Without a separate company/account entity, company data may be entered inconsistently across multiple contacts sharing the same organization. This is flagged for potential normalization in a future iteration.

# Future Scope
Bulk import/export, custom fields, an activity timeline, and introduction of a first-class company/account entity distinct from individual contacts.
