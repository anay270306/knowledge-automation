# Overview
This feature adds multi-factor authentication (MFA) to NovaFlow Workspace using time-based one-time passcodes (TOTP), giving users an additional layer of protection beyond email and password login established in NF-101.

# Backend Changes
Extended the Auth Service to support generating and storing a per-user MFA secret, used to validate TOTP codes during setup and subsequent logins. Introduced an intermediate authentication state that is reached after successful password verification but before a full session is issued, requiring a valid TOTP or recovery code to proceed. Added generation and secure storage of one-time recovery codes at MFA enrollment time, following the same single-use consumption pattern introduced for reset tokens in NF-102.

# Frontend Changes
Added an MFA setup flow within account security settings, including QR code display for authenticator app enrollment and a confirmation step requiring the first TOTP code. Updated the login flow to present a secondary verification screen when MFA is enabled on an account. Added a recovery code entry option as an alternative to the TOTP input during login.

# Database Changes
Added storage for the encrypted MFA secret per user account, an MFA-enabled flag, and a set of hashed recovery codes each with an individual used flag.

# API Changes
Introduced endpoints for initiating MFA enrollment, confirming enrollment with a verification code, validating a TOTP or recovery code during login, and disabling MFA. The disable endpoint requires re-authentication as specified in the acceptance criteria.

# Validation
TOTP codes are validated within the standard 30-second window with limited clock-skew tolerance. Recovery codes are validated against stored hashes and marked as used immediately upon successful consumption. Disabling MFA requires both password and a second factor to prevent unauthorized removal of the protection.

# Performance
TOTP validation is a lightweight, stateless cryptographic check and is not expected to introduce meaningful latency to the login flow. Recovery code lookups are indexed for constant-time retrieval.

# Testing
Covered by unit tests for TOTP generation and validation logic, recovery code single-use enforcement, integration tests for the full enrollment and login flow, and manual QA for edge cases such as clock skew and recovery code exhaustion.

# Deployment Notes
Requires new columns and a recovery codes table to be migrated prior to rollout. Rollout is being staged behind an internal feature flag to allow controlled enablement per organization before general availability.

# Known Limitations
No support yet for hardware security keys or push-based approval as alternative second factors. Recovery codes are generated once at enrollment with no current self-service regeneration flow.

# Future Improvements
Add support for additional second-factor methods such as push notifications or hardware security keys. Introduce a self-service flow for regenerating recovery codes without fully disabling and re-enabling MFA.
