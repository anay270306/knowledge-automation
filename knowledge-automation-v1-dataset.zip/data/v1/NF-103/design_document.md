# Problem Statement
Password-only authentication, as established in NF-101, is insufficient for enterprise customers with heightened security requirements, since a compromised password alone can grant full account access.

# Current Behaviour
Users authenticate using only email and password. There is no additional verification step, and no mechanism exists for recovering access if a second factor were ever introduced without a fallback path.

# Proposed Solution
Introduce optional multi-factor authentication using industry-standard TOTP codes, paired with one-time recovery codes issued at enrollment. Login is extended with an intermediate verification state that sits between password validation and full session issuance.

# Architecture Considerations
Standard TOTP was chosen over a proprietary mechanism to ensure compatibility with widely available authenticator apps, reducing onboarding friction. The intermediate "pending MFA" authentication state was introduced deliberately to keep session issuance centralized in the Auth Service rather than duplicating that logic across two authentication paths.

# Assumptions
It is assumed users enrolling in MFA have access to a compatible authenticator application on a separate device, and that they will securely store their issued recovery codes.

# Risks
Loss of both the authenticator device and recovery codes would lock a user out of their account, requiring administrator-assisted recovery, which is not yet covered by this feature.

# Future Scope
Future iterations may introduce additional second-factor options, self-service recovery code regeneration, and administrator-assisted MFA reset workflows for account lockout scenarios.
