# Overview
This feature introduces the Analytics module's first capability, a usage analytics dashboard built on top of the widget framework established in NF-107, giving administrators visibility into active users and per-module activity.

# Backend Changes
Added an Analytics Service aggregating active user counts and per-module usage metrics over configurable time ranges, exposed through the same data-source contract defined by the NF-107 widget framework rather than a separate rendering pipeline.

# Frontend Changes
Registered two new widget types (active users, per-module usage breakdown) against the existing NF-107 dashboard framework, plus a CSV export action scoped to the current view.

# Database Changes
Added usage_events aggregation tables summarizing raw activity data into time-range-bucketed metrics for efficient dashboard querying.

# API Changes
Added data-source endpoints conforming to the NF-107 widget contract for the two new metric types, plus a CSV export endpoint for the current dashboard view.

# Validation
Time range selections are validated against the supported set (7, 30, 90 days). CSV export respects the same data scoping as the on-screen view.

# Performance
Usage metrics are pre-aggregated into summary tables on a scheduled basis rather than computed from raw event data on every dashboard load, keeping widget refresh fast and consistent with NF-107's polling model.

# Testing
Covered by unit tests for metric aggregation logic, integration tests confirming the new widgets render correctly within the NF-107 framework and refresh on the established interval, and manual QA of the CSV export.

# Deployment Notes
Requires usage_events aggregation table migrations and a scheduled aggregation job. No feature flag required since this extends an already-released framework with new, additive widget types.

# Known Limitations
Usage metrics are aggregated at a daily granularity, not real-time. No drill-down from per-module breakdown into individual user activity yet.

# Future Improvements
Consider finer-grained aggregation intervals if real-time visibility is requested, and add drill-down capability from module-level metrics to individual user activity.
