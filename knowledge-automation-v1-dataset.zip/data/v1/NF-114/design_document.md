# Problem Statement
The audit record introduced in NF-104 was narrowly scoped to MFA resets, leaving no consistent mechanism for other modules to record sensitive actions, risking inconsistent or missing audit trails as the platform grows.

# Current Behaviour
Only MFA reset actions are audited, using a purpose-built table introduced in NF-104. No other module has an equivalent capability.

# Proposed Solution
Generalize the audit record into a centralized Audit Logging Service with a module-agnostic event schema, migrating the existing MFA reset records into the new store rather than starting from an empty log.

# Architecture Considerations
The event schema was deliberately kept generic (actor, action, target, timestamp, optional metadata) to avoid encoding MFA-specific concepts into the shared model, ensuring genuine reusability across modules such as Permissions, Billing, and User Management.

# Assumptions
It is assumed that historical MFA reset audit data must be preserved for compliance continuity, rather than treated as disposable.

# Risks
The backfill migration of historical MFA reset records carries some risk of data transformation errors. This is mitigated through dedicated migration tests validating data fidelity.

# Future Scope
Per-action-type retention configuration and audit log export for compliance reporting.
