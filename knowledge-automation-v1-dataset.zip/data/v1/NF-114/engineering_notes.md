# Overview
This feature introduces a centralized Audit Logging Service, generalizing the ad hoc audit record type first introduced for administrator-assisted MFA resets in NF-104 into a shared capability usable by any module.

# Backend Changes
Added an Audit Logging Service exposing a generic event-recording interface (actor, action, target, timestamp, and an optional metadata payload). Migrated the existing MFA reset audit records from NF-104 into the new centralized event store via a backfill migration, preserving original actor/target/timestamp data.

# Frontend Changes
Added an audit log view in the Admin Console supporting filtering by actor, action type, and date range.

# Database Changes
Added a generic audit_events table designed to be module-agnostic, replacing the narrower MFA-reset-specific audit table introduced in NF-104.

# API Changes
Added an internal recording endpoint for module services to call, and an administrator-facing endpoint for querying the audit log with filters.

# Validation
Audit events are write-once; the API exposes no update or delete operation, and the database layer enforces this at the service level.

# Performance
Audit log queries are indexed on actor, action type, and timestamp to keep filtered queries performant as event volume grows across modules.

# Testing
Covered by unit tests for the generic event-recording interface and immutability enforcement, integration tests confirming the NF-104 MFA reset flow now writes through the centralized service, and migration tests validating the backfill preserved historical MFA reset records accurately.

# Deployment Notes
Requires the new audit_events table migration and a one-time backfill migration of existing MFA reset records. Rollout is staged behind an internal feature flag during backfill validation.

# Known Limitations
Retention configuration is available at the organization level but defaults are not yet customizable per action type. No export capability for audit logs yet.

# Future Improvements
Support per-action-type retention configuration, and add audit log export for compliance reporting purposes.
