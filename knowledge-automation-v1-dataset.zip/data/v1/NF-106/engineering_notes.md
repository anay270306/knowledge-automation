# Overview
This feature introduces the Reporting module's first capability: scheduled report generation with automated email delivery, reducing reliance on manual exports for stakeholders who need recurring visibility into key metrics.

# Backend Changes
Added a Reporting Service responsible for rendering report templates on a schedule, along with a new background job scheduler component that evaluates due schedules and triggers generation. Delivery reuses the asynchronous email dispatch pattern established in NF-102 rather than building a separate pipeline.

# Frontend Changes
Added a schedule creation UI supporting template selection, recipient entry, and a recurrence picker (daily, weekly, monthly). Added pause, resume, and delete controls, along with a run history view showing delivery status per generated instance.

# Database Changes
Added a scheduled_reports table storing schedule configuration and a report_run_history table capturing the outcome and delivery status of each generated instance.

# API Changes
Introduced endpoints for creating, updating, pausing, resuming, and deleting scheduled reports, along with an endpoint for listing run history for a given schedule.

# Validation
Recurrence pattern is validated against supported values, recipient email addresses are validated for format, and template existence is validated before a schedule can be created.

# Performance
The job scheduler processes due schedules asynchronously in batches, fully decoupled from the request/response cycle of the web application.

# Testing
Covered by unit tests for scheduler logic, integration tests for the full schedule-to-delivery flow, and manual QA of pause/resume behavior and failure visibility in the run history view.

# Deployment Notes
Requires migration of the new scheduled_reports and report_run_history tables, along with deployment of the background scheduler worker.

# Known Limitations
No support yet for custom report templates beyond a predefined set. No timezone-aware scheduling; schedules currently run against the organization's default timezone only.

# Future Improvements
Support a custom report builder, timezone-aware scheduling per schedule, and additional export formats beyond the current attachment type.
