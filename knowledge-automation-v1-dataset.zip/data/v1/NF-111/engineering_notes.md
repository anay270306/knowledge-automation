# Overview
This feature introduces the Workflow Automation module's core capability: a rule-based execution engine that reacts to platform events and performs configured actions asynchronously.

# Backend Changes
Added a Workflow Engine service defining a pluggable trigger contract, condition evaluation, and action contract. Initial trigger integrations cover CRM record creation/update (NF-108) and scheduled time-based triggers. Initial action integrations cover sending a notification (via the NF-109 Notification Service) and updating a record field. Execution runs asynchronously via a queue, decoupled from the originating request.

# Frontend Changes
Added a rule builder UI allowing selection of a trigger, optional conditions, and one or more actions, plus an enable/disable toggle and a rule status view showing recent execution outcomes.

# Database Changes
Added a workflow_rules table storing rule definitions, and a workflow_executions table logging each execution attempt with status and retry count.

# API Changes
Added endpoints for creating, updating, enabling, and disabling workflow rules, and for listing recent execution history per rule.

# Validation
Rule creation validates that at least one action is defined and that the selected trigger and action types are registered and compatible.

# Performance
Execution is fully asynchronous and queued, ensuring the record operation that triggered a workflow is not slowed down by rule evaluation or action execution.

# Testing
Covered by unit tests for trigger/condition/action contract dispatch and retry logic, integration tests for the full CRM-contact-created-to-notification-sent flow, and manual QA of enable/disable behavior and failure visibility.

# Deployment Notes
Requires workflow_rules and workflow_executions table migrations, plus deployment of the async execution queue and worker. Rollout is staged behind an internal feature flag for initial validation with a small set of organizations.

# Known Limitations
Only two trigger types and two action types are supported at launch. No support yet for multi-step branching logic beyond simple conditions.

# Future Improvements
Expand trigger and action integrations to additional modules (e.g., Billing, Customer Portal), and support multi-step branching workflows.
