# Overview
This feature introduces a self-service password recovery flow, allowing users to reset a forgotten password via a time-limited email verification link. It builds directly on the authentication foundation established in NF-101.

# Backend Changes
Added logic in the Auth Service to generate a single-use, cryptographically random reset token associated with a user account and a short expiry window. Introduced a check to ensure a token can only be consumed once, after which it is immediately invalidated. On successful password reset, all existing sessions tied to the account are terminated using the session invalidation logic introduced in NF-101.

# Frontend Changes
Added a "Forgot Password" link on the login screen leading to a request form for the registered email address. Added a dedicated reset password page reachable only via the emailed link, containing a new password field with policy guidance and confirmation.

# Database Changes
Added a new table to store password reset tokens, including the associated user reference, token hash, expiry timestamp, and a used flag. Tokens are purged periodically once expired.

# API Changes
Introduced endpoints for requesting a password reset and for submitting a new password using a valid token. Both endpoints are rate-limited to reduce abuse potential.

# Validation
Reset requests return a generic confirmation message regardless of whether the email is registered. Token validity, expiry, and single-use constraints are all enforced server-side before allowing a password change. New password submissions are validated against the existing password policy.

# Performance
Token generation and validation are lightweight operations expected to complete well within standard request latency budgets. Email dispatch is handled asynchronously to avoid blocking the request/response cycle.

# Testing
Covered by unit tests for token generation, expiry, and single-use enforcement, integration tests for the full request-to-reset flow, and manual QA for session invalidation behavior after a successful reset.

# Deployment Notes
Requires the new reset token table to be migrated prior to rollout. No feature flag was used since password recovery is considered essential functionality for v1.

# Known Limitations
No support for alternate recovery channels such as SMS. No secondary verification step beyond email ownership. Rate limiting is applied per email/IP but does not yet include adaptive throttling.

# Future Improvements
Consider adding secondary verification factors for higher-security accounts once multi-factor authentication is introduced. Evaluate adaptive rate limiting as part of a broader security hardening initiative.
