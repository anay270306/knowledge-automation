# Overview
This feature extends the existing email-only Notification Service into a multi-channel service, adding in-app notifications and per-category user preferences on top of the transactional email capability already relied upon by NF-102, NF-104, and NF-105.

# Backend Changes
Added a notification category taxonomy and preference resolution logic that checks the user's configured preference unless the category is flagged as critical, in which case email delivery is always enforced regardless of preference.

# Frontend Changes
Added a notification center UI showing recent in-app notifications with read/unread state and mark-as-read actions, along with a preferences panel under account settings for configuring per-category delivery channels.

# Database Changes
Added a notifications table for in-app notifications, a notification_preferences table scoped per user per category, and a critical flag on category definitions.

# API Changes
Added endpoints for listing in-app notifications, marking notifications as read, and retrieving and updating category preferences.

# Validation
Preference updates are validated against the known category taxonomy. Attempts to disable email delivery for a category flagged as critical are rejected.

# Performance
The in-app notification list is paginated and indexed by user and read state to keep retrieval fast as notification volume grows.

# Testing
Covered by unit tests for preference resolution logic including the critical-category override, integration tests confirming the existing NF-102, NF-104, and NF-105 email flows still function unchanged, and manual QA of the notification center UI.

# Deployment Notes
Requires migration of the new notification-related tables. Existing email dispatch call sites in NF-102, NF-104, and NF-105 were updated to route through the formalized service interface without any change in externally observed behavior.

# Known Limitations
No push notification channel yet, whether mobile or browser-based. No digest or batching option for high-frequency notification categories.

# Future Improvements
Introduce a push notification channel once the Mobile Experience module is further along, and add digest batching for noisy notification categories.
