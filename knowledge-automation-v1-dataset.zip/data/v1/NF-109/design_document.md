# Problem Statement
Notification delivery existed only as an ad hoc email dispatch pattern reused across several features, with no in-app visibility and no user control over delivery channel.

# Current Behaviour
Emails are sent directly from individual features (password reset, MFA reset, invitations) with no centralized preference system or in-app equivalent.

# Proposed Solution
Formalize a multi-channel Notification Service with a category taxonomy, letting users choose in-app, email, or both per category, while enforcing that critical security categories always deliver by email.

# Architecture Considerations
The critical-category override was added specifically to preserve the security guarantees established in the Authentication module across NF-101 through NF-104, ensuring this generalization does not weaken existing behavior.

# Assumptions
It is assumed that existing email call sites can be migrated to the new service interface without changing their externally observed behavior.

# Risks
Migrating existing call sites risks subtle regressions in critical security emails. This is mitigated by explicit integration tests against the NF-102, NF-104, and NF-105 flows.

# Future Scope
A push notification channel, and digest/batching support for high-frequency notification categories.
