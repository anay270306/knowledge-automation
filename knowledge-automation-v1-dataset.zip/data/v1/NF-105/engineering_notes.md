# Overview
This feature introduces the User Management module's first capability: an invitation-based onboarding flow that allows organization administrators to bring new users into their NovaFlow Workspace instance in a controlled manner.

# Backend Changes
Added a new invitation token type in the Auth Service, following the same single-use, time-limited generation pattern established for password reset tokens in NF-102, but scoped to a distinct token category to prevent cross-use between flows. Introduced logic in the User Service to create a pending user record upon invitation, which is only promoted to an active account once the setup flow is completed. Added a check during setup completion to determine whether the organization enforces mandatory MFA, redirecting into the enrollment flow from NF-103 when applicable.

# Frontend Changes
Added an "Invite User" action within the Admin Console, including fields for email address and initial role selection. Added a pending invitations list showing status and allowing revocation or resend. Added a setup page reachable only via the invitation link, where the invited user creates their password and completes account setup.

# Database Changes
Added a new table for invitation tokens, including associated email, assigned role, expiry timestamp, and a used flag. Added a pending/active status field to the user record to distinguish provisioned-but-incomplete accounts from fully onboarded ones.

# API Changes
Introduced endpoints for creating an invitation, resending an invitation, revoking a pending invitation, listing pending invitations, and completing account setup using a valid invitation token.

# Validation
Invitation creation validates that the email is not already associated with an active account in the organization. Setup completion enforces the existing password policy and validates the invitation token's validity, expiry, and single-use constraint before activating the account.

# Performance
Invitation and setup operations are lightweight and not expected to introduce meaningful latency. Invitation emails are dispatched asynchronously, consistent with the pattern established in NF-102.

# Testing
Covered by unit tests for invitation token generation and expiry, integration tests for the full invite-to-active-account flow including the mandatory MFA redirect path, and manual QA of the resend and revoke actions.

# Deployment Notes
Requires the new invitation token table and the pending/active status field migration prior to rollout. No feature flag was used since this establishes baseline User Management functionality required for organization onboarding.

# Known Limitations
No support yet for bulk invitations via file upload. No configurable invitation expiry window; the 7-day period is currently fixed. Role selection at invitation time is limited to a single role, with more granular permission assignment deferred to the Permissions module.

# Future Improvements
Add bulk invitation support for larger organizations. Make the invitation expiry window configurable at the organization level. Extend role assignment at invitation time once the Permissions module is further developed.
