# Overview
This feature introduces a proper Permissions module with custom, module-level permission groups, replacing the single fixed role assigned during invitation in NF-105.

# Backend Changes
Added a Permissions Service defining permission groups as a set of module-scoped access levels (view, edit, manage). Added centralized permission-check middleware used across module API endpoints. Added a migration step mapping each existing single role from NF-105 onto an equivalent default permission group.

# Frontend Changes
Added a permission group management UI in the Admin Console for creating groups and assigning users, and updated the user detail view to show assigned groups instead of a single role.

# Database Changes
Added permission_groups and permission_group_members tables, along with a mapping table used during the one-time migration from the legacy role field.

# API Changes
Added endpoints for creating and updating permission groups, assigning and removing users from groups, and listing group membership. Existing module endpoints were updated to call the centralized permission-check middleware.

# Validation
Group creation validates that at least one module permission is defined. Removing a user's last group defaults them to read-only access rather than leaving them with no defined access.

# Performance
Permission checks are cached per user session to avoid repeated lookups on every API call.

# Testing
Covered by unit tests for the migration mapping logic and permission-check middleware, integration tests confirming existing NF-105 invited users retain equivalent access after migration, and manual QA of the group management UI.

# Deployment Notes
Requires migration of the new permission tables and a one-time data migration run to convert existing single-role assignments into default groups. Rollout is staged behind an internal feature flag during migration validation.

# Known Limitations
No support yet for custom permission levels beyond view/edit/manage. No group hierarchy or inheritance between groups.

# Future Improvements
Support custom, more granular permission levels per module, and evaluate group hierarchy or inheritance for larger organizations.
