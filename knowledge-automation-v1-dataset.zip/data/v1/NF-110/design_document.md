# Problem Statement
The single fixed role assigned during user invitation in NF-105 does not scale to realistic enterprise access control needs, where organizations require custom, module-level permission structures.

# Current Behaviour
Each user has exactly one role assigned at invitation time, with no way to customize or combine permissions across modules.

# Proposed Solution
Introduce permission groups as the unit of access control, each defining module-level permissions, with users assignable to one or more groups. A migration converts existing single-role assignments into equivalent default groups.

# Architecture Considerations
Centralizing permission checks in shared middleware, rather than duplicating checks per module, ensures consistent enforcement and avoids the risk of a module bypassing access control at the API layer.

# Assumptions
It is assumed that the three-tier view/edit/manage permission model is sufficiently granular for v1 needs across all listed module areas.

# Risks
Migration of existing single-role users to groups carries risk of access regression if the mapping is incorrect. This is mitigated through integration testing against NF-105's invitation flow and a staged rollout behind a feature flag.

# Future Scope
More granular custom permission levels, and group hierarchy or inheritance for larger organizational structures.
