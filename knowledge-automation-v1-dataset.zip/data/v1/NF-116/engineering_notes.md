# Overview
This feature introduces the API Management module's first capability, allowing organizations to issue, scope, and revoke API keys for external integrations, with rate limiting to protect platform stability.

# Backend Changes
Added an API Gateway component handling key issuance (scoped to permission groups from NF-110), hashed key storage, revocation, and per-key rate limiting configurable per organization tier. Key lifecycle events and rate-limit violations are recorded through the centralized Audit Logging Service from NF-114.

# Frontend Changes
Added an API key management section in the Admin Console for generating, viewing (once, at creation), and revoking keys, including permission group scoping selection.

# Database Changes
Added an api_keys table storing hashed key values, associated permission group references, and revocation status.

# API Changes
Added endpoints for creating, listing (metadata only, not full key value), and revoking API keys, plus internal rate-limit enforcement middleware applied to all API-key-authenticated requests.

# Validation
Generated keys are shown in full exactly once and never retrievable again. Revoked keys are rejected immediately on subsequent use.

# Performance
Rate-limit counters are maintained in the shared cache layer, consistent with the session approach from NF-101, to keep enforcement checks fast under high request volume.

# Testing
Covered by unit tests for key hashing, scoping, and rate-limit counter logic, integration tests confirming permission group scoping from NF-110 is correctly enforced and that key events appear in the NF-114 audit log, and manual QA of the rate-limit error response.

# Deployment Notes
Requires the new api_keys table migration and rate-limit configuration per organization tier. Rollout is staged behind an internal feature flag for initial validation with select organizations.

# Known Limitations
No support yet for per-endpoint rate limit customization, only a flat per-key limit. No automatic key rotation reminders.

# Future Improvements
Support per-endpoint rate limit customization, and add automatic key rotation reminders for security hygiene.
