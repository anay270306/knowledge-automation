# Overview
This fixes a security gap where changing a password from account settings while logged in did not invalidate other active sessions, unlike the password-reset flow from NF-102 which already enforced this correctly.

# Backend Changes
Wired the account-settings password change path in the Auth Service to call the same session invalidation logic introduced in NF-102, excluding the session used to perform the change so the user is not logged out of their current device.

# Frontend Changes
Added a confirmation message on the account-settings password change form indicating that other active sessions have been signed out.

# Database Changes
No schema changes were required; this fix reuses existing session storage and invalidation mechanisms from NF-101 and NF-102.

# API Changes
The existing account-settings password change endpoint now triggers session invalidation for all sessions other than the current one, matching the behavior of the NF-102 reset-completion endpoint.

# Validation
Existing validation on the account-settings password change flow (current password confirmation, new password policy) is unchanged; only the post-success session handling was modified.

# Performance
No meaningful performance impact, as this reuses the same invalidation mechanism already in place for password reset.

# Testing
Covered by unit tests confirming other sessions are invalidated while the current session remains active, integration tests covering both the account-settings change path and the NF-102 reset path to confirm consistent behavior, and regression tests confirming existing password validation logic is unaffected.

# Deployment Notes
No migration required; this is a behavioral fix within existing infrastructure. No feature flag used given the security-critical nature of the fix.

# Known Limitations
Not applicable.

# Future Improvements
Consider surfacing an explicit "active sessions" management view in account settings, allowing users to view and manually revoke individual sessions rather than only an all-or-nothing invalidation on password change.
