# Problem Statement
The session-invalidation guarantee established for password reset in NF-102 was not consistently applied to the separate account-settings password change path, leaving a security gap where a stolen session token could remain valid after a user changed their password.

# Current Behaviour
The NF-102 password-reset flow correctly invalidates all other sessions on completion, but the account-settings password change path (available to already-authenticated users) does not trigger the same invalidation.

# Proposed Solution
Wire the account-settings password change path to call the same session invalidation logic already used by the NF-102 reset flow, excluding the currently active session.

# Architecture Considerations
Reusing the existing invalidation logic rather than writing a parallel implementation ensures both password-change paths remain consistent going forward and reduces the chance of this class of gap recurring elsewhere.

# Assumptions
It is assumed that users changing their password from account settings expect their current device to remain logged in, while other devices should be signed out, consistent with the NF-102 behavior.

# Risks
No new risk is introduced by this fix; it closes an existing risk rather than creating one. The main residual risk is that any future new password-change entry point could reintroduce a similar gap if it doesn't reuse the shared invalidation logic.

# Future Scope
An explicit active-sessions management view, allowing users to see and selectively revoke individual sessions rather than relying solely on all-or-nothing invalidation triggered by a password change.
